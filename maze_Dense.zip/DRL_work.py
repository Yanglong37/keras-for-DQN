from keras import models
from keras import layers
import tensorflow as tf
import numpy as np

seed = np.random.seed(6)

class drl_work(object):
    def __init__(self,
                 n_actions,
                 n_feature,
                 learning_rate = 0.1,
                 reward_decay = 0.9,
                 e_greedy = 0.9,
                 replace_ilter = 100,
                 memory_size = 1000,
                 batch_size = 32):
        self.n_actions = n_actions
        self.n_feature = n_feature
        self.lr = learning_rate
        self.gamma = reward_decay
        self.epsilon_max = e_greedy
        self.replace_target_ilter = replace_ilter
        self.memory_side = memory_size
        self.bach_size = batch_size

        # 定义学习总步数
        self.lr_step_counter = 0

        # 初始化记忆
        self.memory = np.zeros((self.memory_side,2 * self.n_feature + 2))

        #初始化predict_net和target_net网络
        self.built_network()
        self.change_params()
        self.cost_loss = []
        self.cost_reward = []

    # target_net和predict_net的参数交换
    def change_params(self):
        self.model2.get_layer('D2_1_Params').set_weights(self.model1.get_layer('D1_1_Params').get_weights())
        self.model2.get_layer('D2_2_Params').set_weights(self.model1.get_layer('D1_2_Params').get_weights())
        self.model2.get_layer('D2_3_Params').set_weights(self.model1.get_layer('D1_3_Params').get_weights())



    def built_network(self):
        # ------------------------------------built_predict_network--------------------------------------------
        self.model1 = models.Sequential()
        self.model1.add(layers.Dense(12,activation='relu',input_shape=(36,),kernel_initializer='random_normal',name='D1_1_Params'))
        self.model1.add(layers.Dense(10,activation='relu',kernel_initializer='random_normal',name="D1_2_Params"))
        self.model1.add(layers.Dense(4,activation="softmax",kernel_initializer='random_normal',name='D1_3_Params'))
        self.model1.summary()

        self.model1.compile(loss='mse',
                            optimizer='adam',
                            metrics=['acc'])

        #-------------------------------------built_target_network----------------------------------------------
        self.model2 = models.Sequential()
        self.model2.add(layers.Dense(12,activation='relu',input_shape=(36,),kernel_initializer='random_normal',name='D2_1_Params'))
        self.model2.add(layers.Dense(10,activation='relu',kernel_initializer='random_normal',name='D2_2_Params'))
        self.model2.add(layers.Dense(4,activation='softmax',kernel_initializer='random_normal',name='D2_3_Params'))

        self.model2.compile(loss='mse',
                            optimizer='adam',
                            metrics=['acc'])


    def store_trasition(self,s,a,r,s_):
        if not hasattr(self,'memory_counter'):
            self.memory_counter = 0
        index = self.memory_counter % self.memory_side
        sample = np.hstack((s,[a,r],s_))
        self.memory[index] = sample
        self.memory_counter += 1


    # 根据状态的动作选择
    def choose_action(self,observation):
        observation = observation.reshape(1,36)
        if np.random.uniform() < self.epsilon_max:
            action = np.argmax(self.model1.predict(observation))
            # 输出可用于调试程序
            # print(self.model1.predict(observation))
        else:
            action = np.random.randint(0,self.n_actions)
        return action


    def learn(self):
        if self.lr_step_counter % self.replace_target_ilter == 0:
            self.change_params()
            print('\ntarget_net_params_replaced\n')
        #抽取样本
        if self.memory_counter > self.memory_side:
            sample_index = np.random.choice(self.memory_side,self.bach_size)
        else:
            sample_index = np.random.choice(self.memory_counter,self.bach_size)
        batch_memory = self.memory[sample_index,:]

        batch_s = batch_memory[:,:self.n_feature]
        batch_s_ = batch_memory[:,-self.n_feature:]

        q_eval = self.model1.predict(batch_s)
        q_next = self.model2.predict(batch_s_)
        q_target = q_eval.copy()

        batch_index = np.arange(self.bach_size,dtype=np.int32)
        eval_act_index = batch_memory[:,self.n_feature].astype(int)
        reward = batch_memory[:,self.n_feature + 1]

        # 检测是否含有正奖赏
        c = np.array(np.where(reward == 10))
        if c.size != 0:
            rate = len(c[0]) / self.bach_size
        else:
            rate = 0
        self.cost_reward.append(rate)

        q_target[batch_index,eval_act_index] = reward + self.gamma * np.max(q_next,axis=1)

        #训练网络
        history = self.model1.fit(batch_s,
                                  q_target,
                                  epochs = 500,
                                  verbose = 0)
        self.cost_loss.append(history.history['loss'])
        self.lr_step_counter += 1


    def reward_rate(self):
        self.cost_reward = np.array(self.cost_reward)
        length = len(self.cost_reward)
        epoch = range(0,length)
        self.cost_reward = self.cost_reward[epoch]
        return self.cost_reward, epoch


    def loss_value(self):
        self.loss = np.array(self.cost_loss)
        a, b = self.loss.shape
        self.loss = self.loss.reshape(a * b,)
        length = len(self.loss)
        epoch = range(0,length,10000)
        self.loss = self.loss[epoch]
        return self.loss, epoch

if __name__ == '__main__':
    network = drl_work(n_actions=4,n_feature=36)