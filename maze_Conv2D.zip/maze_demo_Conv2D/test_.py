import numpy as np
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF,ConstantKernel as c
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from keras import layers
from keras import models
import tensorflow as tf

seed = np.random.seed(6)


def built_network( ISWeights):
    # --------------------------------------built_predict_net---------------------------------
    model1 = models.Sequential()
    model1.add(layers.Conv2D(3, (2, 2), activation='relu', kernel_initializer='uniform',input_shape=(6, 6, 1), name='C1_1_Params'))
    model1.add(layers.Conv2D(3, (2, 2), activation='relu',kernel_initializer='uniform', name='C1_2_Params'))
    # model.add(layers.MaxPooling2D((2,2),name='M1_1_Params'))
    model1.add(layers.Flatten())
    model1.add(layers.Dense(4, activation='softmax', kernel_initializer='uniform',name='D1_1_Params'))
    model1.summary()

    def local_loss(y_actural, y_predict):
        return tf.math.reduce_mean(ISWeights * tf.math.squared_difference(y_actural, y_predict))

    model1.compile(loss=local_loss,
                   optimizer='adam',
                   metrics=['acc'])

    data = np.random.randint(0, 5, size=(36,))
    data = data.reshape(1, 6, 6, 1)
    print(model1.predict(data))
    label = np.array([[0.1, 0.2, 0.3, 0.4]])
    model1.fit(data, label, epochs=100, verbose=0)
    print(model1.predict(data))



if __name__ == '__main__':

    model = built_network(ISWeights=0.5)